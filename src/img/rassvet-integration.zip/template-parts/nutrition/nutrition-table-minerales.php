<div class="nutrition-table__item">
    <table>
        <thead>
            <tr>
                <th>Минаралы</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $render->get_table_row($nutrients['minerals']);
            ?>
        </tbody>
    </table>
</div>