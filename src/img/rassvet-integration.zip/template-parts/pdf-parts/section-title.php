<div class="section__title">
    <span><?php echo $section_title ?></span>
    <img src="../assets/img/icons/section-linear.svg" alt="">
</div>