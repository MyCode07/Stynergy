<div class="section__header">
    <div class="logo">
        <img src="../assets/img/logo.png" alt="">
    </div>
    <div class="name"><?php echo $patient_name ?>, <?php echo $patient['age'] ?> лет</div>
</div>