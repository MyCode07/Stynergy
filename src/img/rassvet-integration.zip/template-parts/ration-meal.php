<div class="nutrition-plan__item">
    <div>
        <label><b>Завтрак</b></label>
        <time>10:00</time>
    </div>
    <table>
        <thead>
            <tr>
                <th>Продукт/блюдо</th>
                <th>Кол-во</th>
                <th>Вес</th>
                <th>Ккал</th>
                <th>БЖУ</th>
                <th>Рецепт</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Бананы</td>
                <td>1 шт.</td>
                <td>110 г</td>
                <td>98</td>
                <td>1/0/22</td>
                <td>-</td>
            </tr>
            <tr>
                <td>Вода</td>
                <td>2 шт.</td>
                <td>110 г</td>
                <td>98</td>
                <td>1/0/22</td>
                <td>-</td>
            </tr>
        </tbody>
    </table>
</div>

